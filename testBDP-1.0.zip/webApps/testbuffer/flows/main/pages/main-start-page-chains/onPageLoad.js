define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class onPageLoad extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;

      const callRestGetListOfUsersGetUsersResult = await Actions.callRest(context, {
        endpoint: 'getListOfUsers/getUsers',
      });

      $page.variables.usersADP.data = callRestGetListOfUsersGetUsersResult.body;

      const convertToBDP = await $page.functions.convertToBDP($page.variables.usersADP);

      $page.variables.usersBDP = convertToBDP;
    }
  }

  return onPageLoad;
});
