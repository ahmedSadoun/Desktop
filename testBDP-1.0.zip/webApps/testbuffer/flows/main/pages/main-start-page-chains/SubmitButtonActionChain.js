define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class SubmitButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;
      $page.variables.isSubmitDisable = true;

       let editItems = $page.variables.usersBDP.getSubmittableItems();
       editItems.forEach(element => {
         $page.variables.usersBDP.setItemStatus(element, "submitting");
         $page.functions.commitChangesToDP($page.variables.usersADP.data,element ).then(res=>{
         $page.variables.usersBDP.setItemStatus(element, "submitted");
         }).catch(error=>{
         $page.variables.usersBDP.setItemStatus(element, "unsubmitted", error);
         });
       });
    }
  }

  return SubmitButtonActionChain;
});
