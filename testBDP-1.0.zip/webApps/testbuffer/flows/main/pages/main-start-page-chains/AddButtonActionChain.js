define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class AddButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;
      // let element = document.getElementById("user-table");
      // let dataLength =await $page.variables.usersBDP.getTotalSize();
      // let dataObj = element.getDataForVisibleRow(dataLength-1);
      // console.log("the table dataObj is ", dataObj, "the length is ", dataLength);
      let newlyGeneratedId = $page.functions.getRandomInt(100, 10000);
      let newData = {
        id: newlyGeneratedId,
        name: "Test Test",
        username: "test.test",
        email: "test@test.com",
        phone: "0155100205",
        website: "testTest.org"
      };
      $page.variables.usersBDP.addItem({
        metadata: { key: newData.id, isLeaf: true },
        data: newData
      });

      $page.variables.isSubmitDisable = false;
    }
  }

  return AddButtonActionChain;
});
