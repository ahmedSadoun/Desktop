define(["ojs/ojbufferingdataprovider"], (BufferingDataProvider) => {
  'use strict';

  class PageModule {
  }
  PageModule.prototype.convertToBDP = function (dp) {
    // console.log("the dp is ", dp);
    let dataBDP = new BufferingDataProvider(dp);
    // console.log("dataBDP ", dataBDP);
    // dataBDP.getTotalSize().then(res=>{
    // // console.log("dataBDP.getTotalSize ", res);

    // })
    // console.log("dataBDP.data ", dataBDP.data());

    return dataBDP;
  };
  function findIndex(usersDataList, key) {
    let ar = usersDataList;
    for (let idx = 0; idx < usersDataList.length; idx++) {
      if (ar[idx].id === key) {
        return idx;
      }
    }
    return -1;
  }
  PageModule.prototype.commitChangesToDP = function (usersDataList, editItem) {
    let idx = findIndex(usersDataList, editItem.item.metadata.key);
    let error;
      console.log("the opration is", editItem.operation);
    if (idx > -1) {
      if (editItem.operation === 'update') {
        usersDataList.splice(idx, 1, editItem.item.data);
      }
      else if (editItem.operation === 'remove') {
        usersDataList.splice(idx, 1);
      }
      else {
        error = {
          severity: 'error',
          summary: 'add error',
          detail: 'Row with same key already exists'
        };
      }
    }
    else {
      if (editItem.operation === 'add') {
        usersDataList.splice(usersDataList.length, 0, editItem.item.data);
      }
      else {
        error = {
          severity: 'error',
          summary: editItem.operation + ' error',
          detail: 'Row for key cannot be found'
        };
      }
    }
    if (error) {
      return Promise.reject(error);
    }
    return Promise.resolve();
  };
  PageModule.prototype.getRandomInt=function (min, max) {
  // Ensure that min and max are integers
  min = Math.ceil(min);
  max = Math.floor(max);
  // Generate a random integer in the range [min, max]
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

  return PageModule;
});
